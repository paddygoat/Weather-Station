#ifndef WEATHER_STATION_V3_SOIL_H
#define WEATHER_STATION_V3_SOIL_H

extern void soil();
extern void soilSetup();

extern int moisture;


#endif
